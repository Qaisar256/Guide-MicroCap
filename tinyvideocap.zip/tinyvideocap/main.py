from src.tinyvideocap.config import load_config
from src.tinyvideocap.train import train
import argparse
ap=argparse.ArgumentParser(); ap.add_argument('stage'); ap.add_argument('--config', default='configs/default.yaml'); args=ap.parse_args()
cfg=load_config(args.config)
if args.stage=='train': train(cfg)
else: print('Use: train')
