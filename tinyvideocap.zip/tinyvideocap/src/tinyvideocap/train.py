
import torch, json, random
import torch.nn as nn
from pathlib import Path
from tqdm import tqdm
from .utils.tokenizer import Simple as SimpleTokenizer
from .utils.losses import DistillationLoss
from .data.datasets import gather_split
from .data.preprocess import preprocess_all
from .models.clip_adapter import CLIPAdapterStub
from .models.microcap_decoder import MicroCapDecoder
from .models.teacher import TeacherStub

def train(cfg):
    device = torch.device(cfg['train']['device'])
    texts = preprocess_all(cfg)

    # Tokenizer
    tok = SimpleTokenizer()
    tok.build(texts)
    proc_dir = Path(cfg['paths']['processed_dir'])
    proc_dir.mkdir(parents=True, exist_ok=True)
    (proc_dir / 'tokenizer.json').write_text(json.dumps(tok.vocab))

    # Models
    d_model = cfg['model']['d_model']
    decoder = MicroCapDecoder(len(tok.vocab),
                              d_model=d_model,
                              n_heads=cfg['model']['n_heads'],
                              num_layers=cfg['model']['decoder_layers'],
                              dim_ff=cfg['model']['dim_ff'],
                              dropout=cfg['model'].get('dropout', 0.1),
                              max_len=cfg['model']['max_len']).to(device)

    teacher = None
    if cfg.get('distillation', {}).get('enable', True):
        teacher = TeacherStub(len(tok.vocab),
                              d_model=max(512, d_model+256),
                              n_heads=max(8, cfg['model']['n_heads']+4),
                              num_layers=max(4, cfg['model']['decoder_layers']+2),
                              dim_ff=max(1024, cfg['model']['dim_ff']*2),
                              max_len=cfg['model']['max_len']).to(device)
        for p in teacher.parameters():
            p.requires_grad = False
        teacher.eval()

    encoder = CLIPAdapterStub(out_dim=d_model).to(device)  # acts as frozen
    for p in encoder.parameters():
        p.requires_grad = False
    encoder.eval()

    # Optimizer and loss
    opt = torch.optim.Adam(decoder.parameters(), lr=cfg['train']['lr'], weight_decay=cfg['train'].get('weight_decay', 0.0))
    loss_fn = DistillationLoss(ce_ignore_index=0,
                               lambda_kld=cfg['distillation'].get('lambda_kld', 0.7),
                               lambda_att=cfg['distillation'].get('lambda_att', 0.3),
                               temperature=cfg['distillation'].get('temperature', 1.0))

    # Data
    train_items = []
    for ds in cfg['data']['datasets']:
        train_items += gather_split(cfg['paths']['data_root'], ds, 'train')
    random.shuffle(train_items)
    train_items = train_items[:128]

    decoder.train()
    for epoch in range(cfg['train']['num_epochs']):
        avg = 0.0
        pbar = tqdm(range(0, len(train_items), cfg['train']['batch_size']), desc=f"Epoch {epoch+1}")
        for bi in pbar:
            batch = train_items[bi: bi + cfg['train']['batch_size']]
            if not batch: break

            # Build fake frames for demo (replace with real frame sampling or embeddings in your env)
            B = len(batch)
            frames = torch.randn(B, cfg['data']['frames_per_clip'], 3, 224, 224, device=device)
            vid_emb = encoder(frames)  # [B, T, D]

            # Tokenize
            ids_list = [tok.encode(it['caption'], max_len=cfg['model']['max_len']) for it in batch]
            inp = torch.tensor([ids[:-1] for ids in ids_list], device=device)
            tgt = torch.tensor([ids[1:] for ids in ids_list], device=device)

            # Student
            s_logits, s_att = decoder(inp, vid_emb)

            t_logits = None
            t_att = None
            if teacher is not None:
                with torch.no_grad():
                    t_logits, t_att = teacher(inp, vid_emb)

            loss, parts = loss_fn(s_logits, tgt, teacher_logits=t_logits, student_att=s_att, teacher_att=t_att)

            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(decoder.parameters(), cfg['train'].get('grad_clip', 1.0))
            opt.step()

            avg = 0.9*avg + 0.1*loss.item() if bi>0 else loss.item()
            pbar.set_postfix({"loss": f"{avg:.3f}", "ce": f"{parts['ce']:.3f}", "kld": f"{parts['kld']:.3f}", "att": f"{parts['att']:.3f}"})

        ckpt_dir = Path(cfg['paths']['ckpt_dir']); ckpt_dir.mkdir(parents=True, exist_ok=True)
        torch.save({'decoder': decoder.state_dict(), 'vocab': tok.vocab}, ckpt_dir / f"decoder_epoch{epoch+1}.pt")
    print("Training finished.")
