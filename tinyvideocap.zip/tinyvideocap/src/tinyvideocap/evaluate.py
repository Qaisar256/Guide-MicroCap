
import torch, json, random
from pathlib import Path
from .utils.tokenizer import Simple as SimpleTokenizer
from .utils.metrics import bleu4, cider_proxy
from .data.datasets import gather_split
from .models.clip_adapter import CLIPAdapterStub
from .models.microcap_decoder import MicroCapDecoder

def evaluate(cfg):
    device = torch.device(cfg['train']['device'])
    vocab = json.load(open(Path(cfg['paths']['processed_dir'])/'tokenizer.json'))
    tok = SimpleTokenizer(); tok.vocab = vocab

    ckpt_path = sorted(Path(cfg['paths']['ckpt_dir']).glob('decoder_epoch*.pt'))[-1]
    state = torch.load(ckpt_path, map_location=device)
    decoder = MicroCapDecoder(len(tok.vocab),
                              d_model=cfg['model']['d_model'],
                              n_heads=cfg['model']['n_heads'],
                              num_layers=cfg['model']['decoder_layers'],
                              dim_ff=cfg['model']['dim_ff'],
                              dropout=cfg['model'].get('dropout', 0.1),
                              max_len=cfg['model']['max_len']).to(device)
    decoder.load_state_dict(state['decoder'])
    decoder.eval()

    encoder = CLIPAdapterStub(out_dim=cfg['model']['d_model']).to(device)
    for p in encoder.parameters(): p.requires_grad = False
    encoder.eval()

    items = []
    for ds in cfg['data']['datasets']:
        items += gather_split(cfg['paths']['data_root'], ds, 'test')
    random.shuffle(items)
    items = items[:16]

    refs = []; hyps = []
    for it in items:
        frames = torch.randn(1, cfg['data']['frames_per_clip'], 3, 224, 224, device=device)
        vid_emb = encoder(frames)

        # greedy decode
        ids = [tok.vocab['<bos>']]
        for _ in range(cfg['model']['max_len']-1):
            inp = torch.tensor([ids], device=device)
            logits, _ = decoder(inp, vid_emb)
            nid = int(logits[:, -1, :].argmax(-1))
            if nid == tok.vocab['<eos>']:
                break
            ids.append(nid)
        hyp = tok.decode(ids)
        ref = it['caption']
        refs.append(ref.split()); hyps.append(hyp.split())

    bleu = sum(bleu4(h, [r]) for h,r in zip(hyps, refs)) / max(1, len(hyps))
    cid = sum(cider_proxy(h, [r]) for h,r in zip(hyps, refs)) / max(1, len(hyps))
    print(f"BLEU-4: {bleu:.4f} | CIDEr-proxy: {cid:.4f}")
