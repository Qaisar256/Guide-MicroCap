import yaml
from pathlib import Path

def load_config(p):
    with open(p) as f:
        cfg = yaml.safe_load(f)
    for key in ['results_dir','logs_dir','ckpt_dir','processed_dir']:
        if key in cfg.get('paths', {}): Path(cfg['paths'][key]).mkdir(parents=True, exist_ok=True)
    return cfg
