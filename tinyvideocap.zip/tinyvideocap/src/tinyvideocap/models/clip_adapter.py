
import torch
import torch.nn as nn

class CLIPAdapterStub(nn.Module):
    """Stub that pretends to be a frozen CLIP encoder by mapping frames to embeddings.
    Replace with a real CLIP model or precomputed embeddings in your environment.
    """
    def __init__(self, out_dim=512):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 32, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1)
        )
        self.proj = nn.Linear(64, out_dim)

    def forward(self, frames: torch.Tensor):
        # frames: [B, T, C, H, W]
        B,T,C,H,W = frames.shape
        x = frames.view(B*T, C, H, W)
        x = self.conv(x).view(B*T, -1)
        x = self.proj(x).view(B, T, -1)
        return x.detach()  # act as frozen
