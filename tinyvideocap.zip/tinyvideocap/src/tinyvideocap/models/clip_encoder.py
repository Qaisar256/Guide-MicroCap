import torch, torch.nn as nn
class TinyCNN(nn.Module):
    def __init__(self, out_dim=256):
        super().__init__()
        self.enc=nn.Sequential(nn.Conv2d(3,16,3,2,1),nn.ReLU(),nn.AdaptiveAvgPool2d(1))
        self.proj=nn.Linear(16,out_dim)
    def forward(self, x):
        B,T,C,H,W=x.shape
        y=self.enc(x.view(B*T,C,H,W)).view(B*T,-1)
        y=self.proj(y).view(B,T,-1)
        return y
