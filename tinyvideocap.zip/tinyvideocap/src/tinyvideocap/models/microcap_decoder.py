
import torch
import torch.nn as nn
import torch.nn.functional as F

class CausalMask:
    @staticmethod
    def build(L, device):
        return torch.triu(torch.ones(L, L, device=device), diagonal=1).bool()

class AttnDecoderLayer(nn.TransformerDecoderLayer):
    def __init__(self, d_model=512, nhead=8, dim_feedforward=2048, dropout=0.1, batch_first=True):
        super().__init__(d_model=d_model, nhead=nhead, dim_feedforward=dim_feedforward, dropout=dropout, batch_first=batch_first)
        self.last_self_attn = None

    def _sa_block(self, x, attn_mask, key_padding_mask):
        x2, attn = self.self_attn(x, x, x, attn_mask=attn_mask, key_padding_mask=key_padding_mask, need_weights=True, average_attn_weights=False)
        self.last_self_attn = attn  # (B, heads, L, L)
        return self.dropout1(x2), self.self_attn.out_proj

class MicroCapDecoder(nn.Module):
    def __init__(self, vocab_size, d_model=512, n_heads=8, num_layers=4, dim_ff=2048, dropout=0.1, max_len=32):
        super().__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.max_len = max_len

        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_len, d_model)

        layers = []
        for _ in range(num_layers):
            layers.append(AttnDecoderLayer(d_model=d_model, nhead=n_heads, dim_feedforward=dim_ff, dropout=dropout, batch_first=True))
        self.decoder = nn.ModuleList(layers)
        self.norm = nn.LayerNorm(d_model)
        self.vid_proj = nn.Linear(d_model, d_model)
        self.out = nn.Linear(d_model, vocab_size)

    def forward(self, tgt_ids, vid_emb):
        B, L = tgt_ids.size()
        device = tgt_ids.device
        pos = torch.arange(L, device=device).unsqueeze(0).expand(B, L)
        x = self.tok_emb(tgt_ids) + self.pos_emb(pos)

        memory = self.vid_proj(vid_emb)  # [B, T, D]
        attn_mask = CausalMask.build(L, device)

        attn_maps = []
        y = x
        for layer in self.decoder:
            # TransformerDecoderLayer API expects (tgt, memory, ...)
            y = layer(y, memory, tgt_mask=attn_mask)
            if getattr(layer, "last_self_attn", None) is not None:
                attn_maps.append(layer.last_self_attn)
        y = self.norm(y)
        logits = self.out(y)
        return logits, attn_maps
