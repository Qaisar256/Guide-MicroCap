
import torch
import torch.nn as nn
from .microcap_decoder import MicroCapDecoder

class TeacherStub(nn.Module):
    """A larger decoder used as a stand-in for the Guide model.
    In practice, you would load a real pretrained captioner here.
    """
    def __init__(self, vocab_size, d_model=768, n_heads=12, num_layers=6, dim_ff=3072, max_len=32):
        super().__init__()
        self.decoder = MicroCapDecoder(vocab_size, d_model=d_model, n_heads=n_heads, num_layers=num_layers, dim_ff=dim_ff, max_len=max_len)

    @torch.no_grad()
    def forward(self, tgt_ids, vid_emb):
        self.eval()
        logits, attn = self.decoder(tgt_ids, vid_emb)
        return logits, attn
