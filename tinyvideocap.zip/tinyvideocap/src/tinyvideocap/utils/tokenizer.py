class Simple:
    def __init__(self): self.vocab={'<pad>':0,'<bos>':1,'<eos>':2,'<unk>':3}
    def build(self, texts):
        for t in texts:
            for w in t.lower().split():
                if w not in self.vocab: self.vocab[w]=len(self.vocab)
    def encode(self, t, max_len=32):
        toks=['<bos>']+t.lower().split()[:max_len-2]+['<eos>']
        return [self.vocab.get(w,3) for w in toks]
