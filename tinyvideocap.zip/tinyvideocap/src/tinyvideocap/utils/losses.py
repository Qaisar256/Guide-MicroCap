
import torch
import torch.nn as nn
import torch.nn.functional as F

class DistillationLoss(nn.Module):
    def __init__(self, ce_ignore_index=0, lambda_kld=0.7, lambda_att=0.3, temperature=1.0):
        super().__init__()
        self.ce = nn.CrossEntropyLoss(ignore_index=ce_ignore_index)
        self.lambda_kld = lambda_kld
        self.lambda_att = lambda_att
        self.temperature = temperature

    def forward(self, student_logits, target_ids, teacher_logits=None, student_att=None, teacher_att=None):
        # CE loss (hard labels)
        B, L, V = student_logits.shape
        ce_loss = self.ce(student_logits.reshape(-1, V), target_ids.reshape(-1))

        total = ce_loss
        kld_loss = torch.tensor(0.0, device=student_logits.device)
        att_loss = torch.tensor(0.0, device=student_logits.device)

        if teacher_logits is not None:
            # KL divergence on soft targets
            T = self.temperature
            st = F.log_softmax(student_logits / T, dim=-1)
            te = F.softmax(teacher_logits / T, dim=-1)
            kld_loss = F.kl_div(st, te, reduction="batchmean") * (T * T)
            total = total + self.lambda_kld * kld_loss

        if (student_att is not None) and (teacher_att is not None):
            # attention alignment loss (squared L2)
            # expect list of attention tensors [num_layers x (B, heads, L, L)]
            s_layers = min(len(student_att), len(teacher_att))
            losses = []
            for i in range(s_layers):
                s = student_att[i]
                t = teacher_att[i]
                # match shapes
                if s.shape != t.shape:
                    # interpolate heads/lengths if needed (fallback)
                    # here we simply resize by pad/truncation to min dims
                    b,h,ls,lt = s.shape[0], s.shape[1], s.shape[2], s.shape[3]
                    b2,h2,ls2,lt2 = t.shape[0], t.shape[1], t.shape[2], t.shape[3]
                    hmin, lsmin, ltmin = min(h,h2), min(ls,ls2), min(lt,lt2)
                    s = s[:, :hmin, :lsmin, :ltmin]
                    t = t[:, :hmin, :lsmin, :ltmin]
                losses.append(F.mse_loss(s, t))
            if losses:
                att_loss = sum(losses)/len(losses)
                total = total + self.lambda_att * att_loss

        return total, {"ce": ce_loss.item(), "kld": float(kld_loss.detach().cpu()), "att": float(att_loss.detach().cpu())}
