
from pathlib import Path
import json, csv

def read_csv(path):
    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({'video_id': r.get('video_id', ''), 'caption': r.get('caption', '')})
    return rows

def read_jsonl(path):
    rows = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            rows.append(json.loads(line))
    return rows

def gather_split(data_root, dataset_name, split):
    root = Path(data_root)
    # Prefer processed jsonl
    proc = root / "processed" / "captions" / dataset_name / f"{split}.jsonl"
    if proc.exists():
        return read_jsonl(proc)
    raw_csv = root / "raw" / dataset_name / f"captions_{split}.csv"
    if raw_csv.exists():
        return read_csv(raw_csv)
    # fallback demo
    return [{'video_id': f'{dataset_name}_{split}_{i}', 'caption': 'a person is speaking'} for i in range(20)]
