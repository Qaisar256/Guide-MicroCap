from .datasets import gather_split
from pathlib import Path
import json

def preprocess_all(cfg):
    texts=[]
    for ds in cfg['data']['datasets']:
        items=gather_split(cfg['paths']['data_root'], ds, 'train')
        texts += [it['caption'] for it in items]
    Path(cfg['paths']['processed_dir']).mkdir(parents=True, exist_ok=True)
    return texts
