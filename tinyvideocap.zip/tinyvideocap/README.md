
# TinyVideoCap (Research Scaffold)

A clean, modular scaffold implementing the TinyVideoCap pipeline with **Guide–MicroCap distillation** (CE + KL + attention alignment), a **CLIP adapter stub**, dataset loaders, training, evaluation, and quantization stubs.

## Usage
```bash
pip install -r requirements.txt
python main.py train --config configs/default.yaml
python main.py evaluate --config configs/default.yaml
```

Put your raw datasets or processed captions under `data/`. Replace the CLIP adapter stub with real frozen CLIP or precomputed embeddings for full experiments.
